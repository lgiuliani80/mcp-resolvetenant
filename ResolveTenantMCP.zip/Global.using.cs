global using Microsoft.Extensions.DependencyInjection;
global using Microsoft.Extensions.Hosting;
global using Microsoft.Extensions.Logging;
global using ModelContextProtocol.Server;
global using System.ComponentModel;
global using System.Diagnostics;
global using System.Text.Json;